﻿using System;

namespace QiDiTu.StateMachineFramework.Exceptions
{
    public class SwitchStateException : StateMachineException
    {
        public SwitchStateException()
        {
        }

        public SwitchStateException(string from, string to)
            : base($"State can't switch from {from} to {to}")
        {
        }

        public SwitchStateException(string message)
            : base(message)
        {
        }

        public SwitchStateException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}