﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using Common.Logging;
using QiDiTu.StateMachineFramework.Attributes;
using QiDiTu.StateMachineFramework.Collections;
using QiDiTu.StateMachineFramework.Exceptions;

namespace QiDiTu.StateMachineFramework
{
    public class StringStateMachine
    {
        private static readonly ILog logger = LogManager.GetLogger<StringStateMachine>();

        ///**
        // * Add or remove {@code ActionListener} type
        // * @see #addActionListener(ActionType, Enum, ActionListener)
        // * @see #removeActionListener(ActionType, Enum, ActionListener)
        // */
        public enum ActionType
        {
            EnterState, LeaveState
        }

        public StringStateMachine(object target)
        {
            if (target == null)
            {
                throw new ArgumentNullException(nameof(target));
            }
            Init(target);
            CurrentState = InitialState;
        }

        protected StringStateMachine()
        {
            Init(this);
            CurrentState = InitialState;
        }

        public string InitialState
        {
            get;
            private set;
        }

        public Type StateFieldType { get; } = typeof(string);

        public ISet<string> States { get; } = new HashSet<string>();

        protected readonly IMultiValuedMap<TranslateData, Delegate> TranslateMap =
            new HashSetValuedHashMap<TranslateData, Delegate>();
        protected readonly IMultiValuedMap<TranslateData, Delegate> TranslateActionMap =
            new HashSetValuedHashMap<TranslateData, Delegate>();
        protected readonly IMultiValuedMap<string, Delegate> EnterActionMap =
            new HashSetValuedHashMap<string, Delegate>();
        protected readonly IMultiValuedMap<string, Delegate> LeaveActionMap =
            new HashSetValuedHashMap<string, Delegate>();

        private void Init(object target)
        {
            // 获取所有成员
            InitState(target);

            if (InitialState == null)
            {
                throw new StateMachineInitException("Not find initial state");
            }

            //获取所有方法
            InitMethod(target);

            InitAction(target);
        }

        private void InitState(object target)
        {
            FieldInfo[] fieldInfos = target.GetType().GetFields(BindingFlags.Instance | BindingFlags.Static
                                                        | BindingFlags.Public | BindingFlags.NonPublic);
            foreach (FieldInfo fieldInfo in fieldInfos)
            {
                StateAttribute attribute = fieldInfo.GetCustomAttribute<StateAttribute>();
                if (attribute == null)
                {
                    continue;
                }
                if (fieldInfo.FieldType != StateFieldType)
                {
                    throw new StateMachineInitException($"Attributed field type must is {StateFieldType}. field name: {fieldInfo.Name}");
                }
                var state = (string)fieldInfo.GetValue(this);
                if (string.IsNullOrWhiteSpace(state))
                {
                    throw new StateMachineInitException($"Unsupport state value is null or white space. field name: {fieldInfo.Name}");
                }
                if (attribute.IsInitState)
                {
                    if (InitialState != null)
                    {
                        throw new StateMachineInitException($"Duplicate init state. field name: {fieldInfo.Name}, state: {state}");
                    }
                    InitialState = state;
                }
                if (!States.Add(state))
                {
                    logger.Warn($"Find same state. field name: {fieldInfo.Name}, state: {state}");
                }
            }
        }

        private void InitMethod(object target)
        {
            MethodInfo[] methodInfos = target.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Static
                                                        | BindingFlags.Public | BindingFlags.NonPublic);
            Type translateAttributeType = typeof(TranslationAttribute);
            Type translateType = typeof(TranslateData);
            Type voidType = typeof(void);
            foreach (MethodInfo methodInfo in methodInfos)
            {
                if (!Attribute.IsDefined(methodInfo, translateAttributeType))
                {
                    continue;
                }
                if (methodInfo.ReturnType != voidType)
                {
                    throw new StateMachineInitException($"Attributed method return type must be {voidType.Name}. Mthod: {methodInfo}");
                }
                ParameterInfo[] parameterInfos = methodInfo.GetParameters();
                if (parameterInfos.Length > 1 ||
                    (parameterInfos.Length == 1 && parameterInfos[0].ParameterType != translateType))
                {
                    throw new StateMachineInitException($"Attributed method parameter must be {voidType.Name} or {nameof(TranslateData)}. Mthod: {methodInfo}");
                }

                Lazy<Delegate> delegateLazy = new Lazy<Delegate>(() => GetTranslateMethodDelegate(methodInfo));
                foreach (TranslationAttribute attribute in methodInfo.GetCustomAttributes<TranslationAttribute>())
                {
                    if (attribute.From == null)
                    {
                        throw new StateMachineInitException($"{nameof(attribute.From)} state must not null. Mthod: {methodInfo}");
                    }
                    if (attribute.From != string.Empty && !States.Contains(attribute.From))
                    {
                        throw new StateMachineInitException($"Unknow {nameof(attribute.From)} state: {attribute.From}");
                    }
                    if (attribute.To == null)
                    {
                        throw new StateMachineInitException($"{nameof(attribute.To)} state must not null. Mthod: {methodInfo}");
                    }
                    if (attribute.To != string.Empty && !States.Contains(attribute.To))
                    {
                        throw new StateMachineInitException($"Unknow {nameof(attribute.To)} state: {attribute.To}");
                    }
                    if (!TranslateMap.Put(new TranslateData(attribute.From, attribute.To), delegateLazy.Value))
                    {
                        logger.Warn($"Repeated add method. Method: {methodInfo}");
                    }
                }
            }
        }

        private void InitAction(object target)
        {
            MethodInfo[] methodInfos = target.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Static
                                                        | BindingFlags.Public | BindingFlags.NonPublic);
            
            Type actionAttributeType = typeof(ActionAttribute);
            Type translateType = typeof(TranslateData);
            Type voidType = typeof(void);
            foreach (MethodInfo methodInfo in methodInfos)
            {
                if (!Attribute.IsDefined(methodInfo, actionAttributeType))
                {
                    continue;
                }
                if (methodInfo.ReturnType != voidType)
                {
                    throw new StateMachineInitException($"Attributed method return type must be {voidType.Name}. Mthod: {methodInfo}");
                }
                ParameterInfo[] parameterInfos = methodInfo.GetParameters();
                if (parameterInfos.Length > 1 ||
                    (parameterInfos.Length == 1 && parameterInfos[0].ParameterType != translateType))
                {
                    throw new StateMachineInitException($"Attributed method parameter must be {voidType.Name} or {nameof(TranslateData)}. Mthod: {methodInfo}");
                }

                Lazy<Delegate> delegateLazy = new Lazy<Delegate>(() => GetTranslateMethodDelegate(methodInfo));
                foreach (ActionAttribute attribute in methodInfo.GetCustomAttributes<ActionAttribute>())
                {
                    if (attribute.ActionWork == ActionAttribute.ActionWorkType.WorkOnSignalStateEnterOrLeave)
                    {
                        if (attribute.State == null)
                        {
                            throw new StateMachineInitException($"Action state must not null.Mthod: {methodInfo}");
                        }
                        if (attribute.State != string.Empty && !States.Contains(attribute.State))
                        {
                            throw new StateMachineInitException($"Unknow {nameof(attribute.State)}: {attribute.State}");
                        }

                        if (attribute.Type == ActionType.EnterState)
                        {
                            if (!EnterActionMap.Put(attribute.State, delegateLazy.Value))
                            {
                                logger.Warn($"Repeated add method. Method: {methodInfo}");
                            }
                        }
                        else
                        {
                            if (!LeaveActionMap.Put(attribute.State, delegateLazy.Value))
                            {
                                logger.Warn($"Repeated add method. Method: {methodInfo}");
                            }
                        }
                    }
                    else
                    {
                        if (attribute.Data.From == null)
                        {
                            throw new StateMachineInitException($"{nameof(attribute.Data.From)} state must not null. Mthod: {methodInfo}");
                        }
                        if (attribute.Data.From != string.Empty && !States.Contains(attribute.Data.From))
                        {
                            throw new StateMachineInitException($"Unknow {nameof(attribute.Data.From)} state: {attribute.Data.From}");
                        }
                        if (attribute.Data.To == null)
                        {
                            throw new StateMachineInitException($"{nameof(attribute.Data.To)} state must not null. Mthod: {methodInfo}");
                        }
                        if (attribute.Data.To != string.Empty && !States.Contains(attribute.Data.To))
                        {
                            throw new StateMachineInitException($"Unknow {nameof(attribute.Data.To)} state: {attribute.Data.To}");
                        }

                        if(!TranslateActionMap.Put(new TranslateData(attribute.Data.From, attribute.Data.To), delegateLazy.Value))
                        {
                            logger.Warn($"Repeated add method. Method: {methodInfo}");
                        }
                    }
                }
            }
        }

        private static readonly Type type1 = typeof(Action);
        private static readonly Type type2 = typeof(Action<TranslateData>);

        [SuppressMessage("ReSharper", "ConvertIfStatementToReturnStatement")]
        private Delegate GetTranslateMethodDelegate(MethodInfo methodInfo)
        {
            Type methodDelegateType = methodInfo.GetParameters().Length == 0 ? type1 : type2;
            if (methodInfo.IsStatic)
            {
                return Delegate.CreateDelegate(methodDelegateType, methodInfo);
            }
            return Delegate.CreateDelegate(methodDelegateType, this, methodInfo.Name);
        }

        [SuppressMessage("ReSharper", "ArgumentsStyleStringLiteral")]
        [SuppressMessage("ReSharper", "RedundantArgumentDefaultValue")]
        public TranslateData GlobalTranslateData { get; } = new TranslateData(from: "", to: "");

        public bool ToState(string state)
        {
            if (!States.Contains(state))
            {
                SwitchStateException = new StateNotFoundException(state);
                return false;
            }
            TranslateData data = new TranslateData(CurrentState, state);
            try
            {
                //Get from any to any
                InvokeTranslateDelegates(GlobalTranslateData, data);
                //Get from current state to any
                InvokeTranslateDelegates(new TranslateData(from: CurrentState), data);
                //Get from any to state
                InvokeTranslateDelegates(new TranslateData(to: state), data);
                //Get from current state to state
                InvokeTranslateDelegates(new TranslateData(from: CurrentState, to: state), data);
            }
            catch (Exception exception)
            {
                SwitchStateException = exception;
                return false;
            }

            string lastState = CurrentState;
            CurrentState = state;
            StateHistory.Add(lastState);

            InvokeActionDelegates(LeaveActionMap.ValuesClone(lastState), data);
            InvokeActionDelegates(TranslateActionMap.ValuesClone(data), data);
            InvokeActionDelegates(EnterActionMap.ValuesClone(state), data);
            
            return true;
        }

        private void InvokeTranslateDelegates(TranslateData key, TranslateData data)
        {
            try
            {
                if (!TranslateMap.ContainsKey(key))
                {
                    return;
                }
                ICollection<Delegate> delegates = TranslateMap.ValuesClone(key);
                foreach (Delegate d in delegates)
                {
                    bool hasParameter = d.Method.GetParameters().Length != 0;
                    if (hasParameter)
                    {
                        d.DynamicInvoke(data);
                    }
                    else
                    {
                        d.DynamicInvoke();
                    }
                }
            }
            catch (TargetInvocationException exception)
            {
                throw exception.InnerException ?? exception;
            }
        }

        private void InvokeActionDelegates(ICollection<Delegate> delegates, TranslateData data)
        {
            if (delegates == null)
            {
                return;
            }
            foreach (Delegate d in delegates)
            {
                bool hasParameter = d.Method.GetParameters().Length != 0;
                try
                {
                    if (hasParameter)
                    {
                        d.DynamicInvoke(data);
                    }
                    else
                    {
                        d.DynamicInvoke();
                    }
                }
                catch (Exception exception)
                {
                    try
                    {
                        TranslateActionHandle?.Invoke(exception);
                    }
                    catch (Exception exception1)
                    {
                        logger.Error(exception1);
                    }
                }
            }
        }

        #region Add/Remove Hook
        protected bool AddHook(TranslateData data, Action action)
        {
            return AddHook(data, action as Delegate);
        }

        protected bool AddHook(TranslateData data, Action<TranslateData> action)
        {
            return AddHook(data, action as Delegate);
        }

        private bool AddHook(TranslateData data, Delegate action)
        {
            if (action == null)
            {
                throw new ArgumentNullException(nameof(action));
            }
            return TranslateMap.Put(data, action);
        }

        protected bool RemoveHook(TranslateData data, Action action)
        {
            return RemoveHook(data, action as Delegate);
        }

        protected bool RemoveHook(TranslateData data, Action<TranslateData> action)
        {
            return RemoveHook(data, action as Delegate);
        }

        private bool RemoveHook(TranslateData data, Delegate action)
        {
            if (action == null)
            {
                throw new ArgumentNullException(nameof(action));
            }
            return TranslateMap.RemoveMapping(data, action);
        }
        #endregion
        
        #region Add/Remove Action
        public bool AddAction(TranslateData data, Action action)
        {
            return AddAction(data, action as Delegate);
        }

        public bool AddAction(TranslateData data, Action<TranslateData> action)
        {
            return AddAction(data, action as Delegate);
        }

        private bool AddAction(TranslateData data, Delegate action)
        {
            if (action == null)
            {
                throw new ArgumentNullException(nameof(action));
            }
            return TranslateActionMap.Put(data, action);
        }

        public bool RemoveAction(TranslateData data, Action action)
        {
            return RemoveAction(data, action as Delegate);
        }

        public bool RemoveAction(TranslateData data, Action<TranslateData> action)
        {
            return RemoveAction(data, action as Delegate);
        }

        private bool RemoveAction(TranslateData data, Delegate action)
        {
            if (action == null)
            {
                throw new ArgumentNullException(nameof(action));
            }
            return TranslateActionMap.RemoveMapping(data, action);
        }

        public bool AddAction(string state, ActionType type, Action action)
        {
            return AddAction(state, type, action as Delegate);
        }

        public bool AddAction(string state, ActionType type, Action<TranslateData> action)
        {
            return AddAction(state, type, action as Delegate);
        }

        private bool AddAction(string state, ActionType type, Delegate action)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }
            if (action == null)
            {
                throw new ArgumentNullException(nameof(action));
            }
            return type == ActionType.EnterState ? 
                        EnterActionMap.Put(state, action) :
                        LeaveActionMap.Put(state, action);
        }

        public bool RemoveAction(string state, ActionType type, Action action)
        {
            return RemoveAction(state, type, action as Delegate);
        }

        public bool RemoveAction(string state, ActionType type, Action<TranslateData> action)
        {
            return RemoveAction(state, type, action as Delegate);
        }

        private bool RemoveAction(string state, ActionType type, Delegate action)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }
            if (action == null)
            {
                throw new ArgumentNullException(nameof(action));
            }
            return type == ActionType.EnterState ?
                EnterActionMap.RemoveMapping(state, action) :
                LeaveActionMap.RemoveMapping(state, action);
        }
        #endregion

        public Exception SwitchStateException
        {
            get;
            protected set;
        }

        public string CurrentState
        {
            get;
            private set;
        }

        protected Action<Exception> TranslateActionHandle
        {
            get;
            set;
        }

        protected IList<string> StateHistory { get; } = new List<string>();

        public static readonly Action Allow = () => { };
    }

    
}
