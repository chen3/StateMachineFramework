﻿using System;

namespace QiDiTu.StateMachineFramework.Attributes
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
    public class TranslationAttribute : Attribute
    {
        public string From { get; set; } = string.Empty;

        public string To { get; set; } = string.Empty;

        public override string ToString()
        {
            return $"{nameof(TranslationAttribute)}({nameof(From)}: {From ?? "<Any>"}, {nameof(To)}: {To ?? "<Any>"})";
        }
    }
}