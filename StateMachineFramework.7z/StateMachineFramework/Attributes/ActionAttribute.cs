﻿using System;

namespace QiDiTu.StateMachineFramework.Attributes
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
    public class ActionAttribute : Attribute
    {
        public ActionAttribute(string state, StringStateMachine.ActionType type)
        {
            State = state;
            Type = type;
            ActionWork = ActionWorkType.WorkOnSignalStateEnterOrLeave;
        }

        public ActionAttribute(string from, string to)
        {
            Data = new TranslateData(from, to);
            ActionWork = ActionWorkType.WorkOnSpecifiedStateSwitch;
        }

        public TranslateData Data { get; }

        public string State { get; }

        public StringStateMachine.ActionType Type { get; }

        public ActionWorkType ActionWork { get; }

        public enum ActionWorkType
        {
            WorkOnSpecifiedStateSwitch, WorkOnSignalStateEnterOrLeave
        }

        public override string ToString()
        {
            return ActionWork == ActionWorkType.WorkOnSpecifiedStateSwitch 
                    ? $"{nameof(ActionAttribute)}({nameof(Data.From)}: {Data.From ?? "<Any>"}, {nameof(Data.To)}: {Data.To ?? "<Any>"})" 
                    : $"{nameof(ActionAttribute)}({nameof(State)}: {State}, {nameof(Type)}: {Type})";
        }
    }
}