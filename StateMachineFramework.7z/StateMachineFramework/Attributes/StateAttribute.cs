﻿using System;

namespace QiDiTu.StateMachineFramework.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public sealed class StateAttribute : Attribute
    {
        public bool IsInitState { get; set; } = false;

        public override string ToString()
        {
            return $"{nameof(StateAttribute)}({nameof(IsInitState)}: {IsInitState})";
        }
    }
}
