﻿using System;

namespace QiDiTu.StateMachineFramework
{
    public struct TranslateData
    {
        public TranslateData(string from = "", string to = "")
        {
            From = from ?? throw new ArgumentNullException(nameof(from));
            To = to ?? throw new ArgumentNullException(nameof(to));
        }

        public string From { get; }

        public string To { get; }
        
        public override int GetHashCode()
        {
            return From?.GetHashCode() ?? 0 + To?.GetHashCode() ?? 0;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is TranslateData))
            {
                return false;
            }
            TranslateData data = (TranslateData) obj;
            return From == data.From && To == data.To;
        }

        public override string ToString()
        {
            return $"{nameof(TranslateData)}({nameof(From)}: {From}, {nameof(To)}: {To})";
        }
    }
}